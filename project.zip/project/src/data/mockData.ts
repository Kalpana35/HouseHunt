import { Property, User, Inquiry } from '../types';

export const mockProperties: Property[] = [
  {
    id: '1',
    title: 'Modern Downtown Apartment',
    description: 'Spacious 2-bedroom apartment in the heart of downtown with stunning city views and modern amenities.',
    price: 2500,
    location: {
      address: '123 Main Street',
      city: 'New York',
      state: 'NY',
      zipCode: '10001'
    },
    type: 'apartment',
    bedrooms: 2,
    bathrooms: 2,
    area: 1200,
    amenities: ['WiFi', 'Air Conditioning', 'Gym', 'Parking', 'Pool', 'Balcony'],
    images: [
      'https://images.pexels.com/photos/1428077/pexels-photo-1428077.jpeg',
      'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg'
    ],
    owner: {
      id: '2',
      name: 'John Smith',
      email: 'john@example.com',
      phone: '+1-555-0123'
    },
    available: true,
    dateAvailable: '2024-02-01',
    createdAt: '2024-01-15',
    status: 'available'
  },
  {
    id: '2',
    title: 'Cozy Studio Near University',
    description: 'Perfect studio apartment for students, walking distance to campus with all utilities included.',
    price: 1200,
    location: {
      address: '456 College Ave',
      city: 'Boston',
      state: 'MA',
      zipCode: '02115'
    },
    type: 'studio',
    bedrooms: 0,
    bathrooms: 1,
    area: 600,
    amenities: ['WiFi', 'Laundry', 'Furnished', 'Near Public Transport'],
    images: [
      'https://images.pexels.com/photos/2736834/pexels-photo-2736834.jpeg',
      'https://images.pexels.com/photos/1743229/pexels-photo-1743229.jpeg'
    ],
    owner: {
      id: '3',
      name: 'Sarah Johnson',
      email: 'sarah@example.com',
      phone: '+1-555-0456'
    },
    available: true,
    dateAvailable: '2024-01-20',
    createdAt: '2024-01-10',
    status: 'available'
  },
  {
    id: '3',
    title: 'Family House with Garden',
    description: 'Beautiful 3-bedroom house with private garden, perfect for families. Quiet neighborhood with excellent schools.',
    price: 3200,
    location: {
      address: '789 Oak Street',
      city: 'San Francisco',
      state: 'CA',
      zipCode: '94102'
    },
    type: 'house',
    bedrooms: 3,
    bathrooms: 2,
    area: 1800,
    amenities: ['Garden', 'Parking', 'Pet Friendly', 'Fireplace', 'Garage'],
    images: [
      'https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg',
      'https://images.pexels.com/photos/1029599/pexels-photo-1029599.jpeg'
    ],
    owner: {
      id: '4',
      name: 'Michael Brown',
      email: 'michael@example.com',
      phone: '+1-555-0789'
    },
    available: true,
    dateAvailable: '2024-02-15',
    createdAt: '2024-01-05',
    status: 'available'
  },
  {
    id: '4',
    title: 'Luxury High-Rise Condo',
    description: 'Premium 2-bedroom condo with panoramic views, concierge service, and luxury amenities.',
    price: 4500,
    location: {
      address: '321 Tower Blvd',
      city: 'Miami',
      state: 'FL',
      zipCode: '33101'
    },
    type: 'condo',
    bedrooms: 2,
    bathrooms: 2,
    area: 1400,
    amenities: ['Concierge', 'Pool', 'Gym', 'Spa', 'Valet Parking', 'Ocean View'],
    images: [
      'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg',
      'https://images.pexels.com/photos/1457842/pexels-photo-1457842.jpeg'
    ],
    owner: {
      id: '5',
      name: 'Emily Davis',
      email: 'emily@example.com',
      phone: '+1-555-0321'
    },
    available: true,
    dateAvailable: '2024-03-01',
    createdAt: '2024-01-20',
    status: 'available'
  }
];

export const mockUsers: User[] = [
  {
    id: '1',
    name: 'Admin User',
    email: 'admin@househunt.com',
    phone: '+1-555-0000',
    role: 'admin',
    approved: true,
    createdAt: '2024-01-01'
  },
  {
    id: '2',
    name: 'John Smith',
    email: 'john@example.com',
    phone: '+1-555-0123',
    role: 'owner',
    approved: true,
    createdAt: '2024-01-10'
  },
  {
    id: '3',
    name: 'Sarah Johnson',
    email: 'sarah@example.com',
    phone: '+1-555-0456',
    role: 'owner',
    approved: true,
    createdAt: '2024-01-05'
  },
  {
    id: '6',
    name: 'Alice Cooper',
    email: 'alice@example.com',
    phone: '+1-555-0654',
    role: 'renter',
    approved: true,
    createdAt: '2024-01-20'
  }
];

export const mockInquiries: Inquiry[] = [
  {
    id: '1',
    propertyId: '1',
    renterId: '6',
    renterName: 'Alice Cooper',
    renterEmail: 'alice@example.com',
    renterPhone: '+1-555-0654',
    message: 'I am interested in this apartment. Can we schedule a viewing?',
    status: 'pending',
    createdAt: '2024-01-22'
  }
];
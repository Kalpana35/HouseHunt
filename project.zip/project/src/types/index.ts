export interface Property {
  id: string;
  title: string;
  description: string;
  price: number;
  location: {
    address: string;
    city: string;
    state: string;
    zipCode: string;
  };
  type: 'apartment' | 'house' | 'studio' | 'condo';
  bedrooms: number;
  bathrooms: number;
  area: number;
  amenities: string[];
  images: string[];
  owner: {
    id: string;
    name: string;
    email: string;
    phone: string;
  };
  available: boolean;
  dateAvailable: string;
  createdAt: string;
  status: 'available' | 'rented' | 'pending';
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'admin' | 'owner' | 'renter';
  profileImage?: string;
  approved: boolean;
  createdAt: string;
}

export interface Inquiry {
  id: string;
  propertyId: string;
  renterId: string;
  renterName: string;
  renterEmail: string;
  renterPhone: string;
  message: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

export interface SearchFilters {
  location: string;
  minPrice: number;
  maxPrice: number;
  propertyType: string;
  bedrooms: number;
  bathrooms: number;
  amenities: string[];
}
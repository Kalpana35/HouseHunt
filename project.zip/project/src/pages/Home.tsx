import React, { useState, useEffect } from 'react';
import { Search } from 'lucide-react';
import PropertyCard from '../components/PropertyCard';
import SearchFilters from '../components/SearchFilters';
import PropertyModal from '../components/PropertyModal';
import { Property, SearchFilters as FilterType, Inquiry } from '../types';
import { mockProperties, mockInquiries } from '../data/mockData';
import { useAuth } from '../context/AuthContext';

const Home: React.FC = () => {
  const [properties, setProperties] = useState<Property[]>(mockProperties);
  const [filteredProperties, setFilteredProperties] = useState<Property[]>(mockProperties);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [inquiries, setInquiries] = useState<Inquiry[]>(mockInquiries);
  const { user } = useAuth();

  const [filters, setFilters] = useState<FilterType>({
    location: '',
    minPrice: 0,
    maxPrice: 0,
    propertyType: '',
    bedrooms: 0,
    bathrooms: 0,
    amenities: []
  });

  useEffect(() => {
    filterProperties();
  }, [properties, filters, searchQuery]);

  const filterProperties = () => {
    let filtered = properties.filter(property => {
      // Basic search
      const matchesSearch = searchQuery === '' || 
        property.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        property.location.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
        property.location.state.toLowerCase().includes(searchQuery.toLowerCase());

      // Location filter
      const matchesLocation = filters.location === '' ||
        property.location.city.toLowerCase().includes(filters.location.toLowerCase()) ||
        property.location.state.toLowerCase().includes(filters.location.toLowerCase());

      // Price filter
      const matchesPrice = 
        (filters.minPrice === 0 || property.price >= filters.minPrice) &&
        (filters.maxPrice === 0 || property.price <= filters.maxPrice);

      // Property type filter
      const matchesType = filters.propertyType === '' || property.type === filters.propertyType;

      // Bedrooms filter
      const matchesBedrooms = filters.bedrooms === 0 || property.bedrooms >= filters.bedrooms;

      // Bathrooms filter
      const matchesBathrooms = filters.bathrooms === 0 || property.bathrooms >= filters.bathrooms;

      // Amenities filter
      const matchesAmenities = filters.amenities.length === 0 ||
        filters.amenities.every(amenity => property.amenities.includes(amenity));

      return matchesSearch && matchesLocation && matchesPrice && matchesType && 
             matchesBedrooms && matchesBathrooms && matchesAmenities;
    });

    setFilteredProperties(filtered);
  };

  const handleInquiry = (propertyId: string, message: string) => {
    if (!user) return;

    const newInquiry: Inquiry = {
      id: Date.now().toString(),
      propertyId,
      renterId: user.id,
      renterName: user.name,
      renterEmail: user.email,
      renterPhone: user.phone,
      message,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    setInquiries([...inquiries, newInquiry]);
    
    // Save to localStorage
    const savedInquiries = JSON.parse(localStorage.getItem('inquiries') || '[]');
    savedInquiries.push(newInquiry);
    localStorage.setItem('inquiries', JSON.stringify(savedInquiries));

    alert('Inquiry sent successfully! The property owner will contact you soon.');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Find Your Perfect
              <span className="block text-blue-200">Rental Home</span>
            </h1>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Discover thousands of rental properties from verified owners. 
              Your dream home is just a click away.
            </p>
            
            {/* Quick Search */}
            <div className="max-w-2xl mx-auto">
              <div className="relative">
                <Search className="absolute left-4 top-4 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search by city, neighborhood, or property name..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 text-gray-900 rounded-xl border-0 shadow-lg focus:ring-4 focus:ring-blue-200"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-80">
            <div className="lg:hidden mb-4">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="w-full bg-white border border-gray-300 rounded-lg px-4 py-2 text-left flex justify-between items-center"
              >
                <span>Filters</span>
                <Search className="h-4 w-4" />
              </button>
            </div>
            
            <div className={`${showFilters ? 'block' : 'hidden'} lg:block`}>
              <SearchFilters
                filters={filters}
                onFiltersChange={setFilters}
                onSearch={filterProperties}
              />
            </div>
          </div>

          {/* Properties Grid */}
          <div className="flex-1">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900">
                Available Properties ({filteredProperties.length})
              </h2>
            </div>

            {filteredProperties.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-gray-400 mb-4">
                  <Search className="h-16 w-16 mx-auto" />
                </div>
                <h3 className="text-xl font-semibold text-gray-600 mb-2">
                  No properties found
                </h3>
                <p className="text-gray-500">
                  Try adjusting your search filters to find more properties.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredProperties.map(property => (
                  <PropertyCard
                    key={property.id}
                    property={property}
                    onSelect={setSelectedProperty}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Property Modal */}
      {selectedProperty && (
        <PropertyModal
          property={selectedProperty}
          onClose={() => setSelectedProperty(null)}
          onInquiry={handleInquiry}
        />
      )}
    </div>
  );
};

export default Home;
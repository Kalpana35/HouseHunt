import React, { useState, useEffect } from 'react';
import { Search, MessageCircle, Calendar, MapPin } from 'lucide-react';
import { Property, Inquiry } from '../../types';
import { mockProperties, mockInquiries } from '../../data/mockData';
import { useAuth } from '../../context/AuthContext';

const RenterDashboard: React.FC = () => {
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [properties] = useState<Property[]>(mockProperties);
  const { user } = useAuth();

  useEffect(() => {
    // Load user's inquiries
    const savedInquiries = JSON.parse(localStorage.getItem('inquiries') || '[]');
    const userInquiries = savedInquiries.filter((inquiry: Inquiry) => inquiry.renterId === user?.id);
    setInquiries([...mockInquiries.filter(i => i.renterId === user?.id), ...userInquiries]);
  }, [user]);

  const getPropertyById = (id: string) => properties.find(p => p.id === id);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Renter Dashboard</h1>
          <p className="text-gray-600 mt-2">Welcome back, {user?.name}!</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Stats Cards */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center">
              <MessageCircle className="h-8 w-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Inquiries</p>
                <p className="text-2xl font-bold text-gray-900">{inquiries.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center">
              <Calendar className="h-8 w-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Approved</p>
                <p className="text-2xl font-bold text-gray-900">
                  {inquiries.filter(i => i.status === 'approved').length}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center">
              <Search className="h-8 w-8 text-amber-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Pending</p>
                <p className="text-2xl font-bold text-gray-900">
                  {inquiries.filter(i => i.status === 'pending').length}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Inquiries List */}
        <div className="bg-white rounded-xl shadow-lg">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">My Property Inquiries</h2>
          </div>

          {inquiries.length === 0 ? (
            <div className="p-8 text-center">
              <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No inquiries yet</h3>
              <p className="text-gray-600">
                Start browsing properties and send inquiries to owners.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {inquiries.map((inquiry) => {
                const property = getPropertyById(inquiry.propertyId);
                return (
                  <div key={inquiry.id} className="p-6">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                      <div className="flex-1">
                        <div className="flex items-start space-x-4">
                          {property && (
                            <img
                              src={property.images[0]}
                              alt={property.title}
                              className="w-16 h-16 rounded-lg object-cover"
                            />
                          )}
                          <div className="flex-1">
                            <h3 className="text-lg font-medium text-gray-900">
                              {property?.title || 'Property Not Found'}
                            </h3>
                            {property && (
                              <div className="flex items-center text-gray-600 mt-1">
                                <MapPin className="h-4 w-4 mr-1" />
                                <span className="text-sm">
                                  {property.location.city}, {property.location.state}
                                </span>
                              </div>
                            )}
                            <p className="text-gray-600 mt-2 text-sm">{inquiry.message}</p>
                            <p className="text-xs text-gray-500 mt-2">
                              Sent on {new Date(inquiry.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      </div>
                      <div className="mt-4 sm:mt-0 sm:ml-6">
                        <span className={`inline-flex px-3 py-1 text-xs font-medium rounded-full ${getStatusColor(inquiry.status)}`}>
                          {inquiry.status.charAt(0).toUpperCase() + inquiry.status.slice(1)}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RenterDashboard;
import React, { useState, useEffect } from 'react';
import { Users, Home, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { User, Property, Inquiry } from '../../types';
import { mockUsers, mockProperties, mockInquiries } from '../../data/mockData';

const AdminDashboard: React.FC = () => {
  const [users, setUsers] = useState<User[]>(mockUsers);
  const [properties] = useState<Property[]>(mockProperties);
  const [inquiries] = useState<Inquiry[]>(mockInquiries);
  const [pendingOwners, setPendingOwners] = useState<User[]>([]);

  useEffect(() => {
    // Load pending owners from localStorage
    const savedUsers = JSON.parse(localStorage.getItem('users') || '[]');
    const pending = savedUsers.filter((user: User) => user.role === 'owner' && !user.approved);
    setPendingOwners(pending);
  }, []);

  const handleApproveOwner = (userId: string) => {
    setPendingOwners(prev => prev.filter(user => user.id !== userId));
    
    // Update localStorage
    const savedUsers = JSON.parse(localStorage.getItem('users') || '[]');
    const updated = savedUsers.map((user: User) => 
      user.id === userId ? { ...user, approved: true } : user
    );
    localStorage.setItem('users', JSON.stringify(updated));
    
    alert('Owner approved successfully!');
  };

  const handleRejectOwner = (userId: string) => {
    setPendingOwners(prev => prev.filter(user => user.id !== userId));
    
    // Remove from localStorage
    const savedUsers = JSON.parse(localStorage.getItem('users') || '[]');
    const filtered = savedUsers.filter((user: User) => user.id !== userId);
    localStorage.setItem('users', JSON.stringify(filtered));
    
    alert('Owner application rejected.');
  };

  const totalUsers = users.length + pendingOwners.length;
  const approvedOwners = users.filter(u => u.role === 'owner' && u.approved).length;
  const totalRenters = users.filter(u => u.role === 'renter').length;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600 mt-2">Platform management and oversight</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center">
              <Users className="h-8 w-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Users</p>
                <p className="text-2xl font-bold text-gray-900">{totalUsers}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center">
              <Home className="h-8 w-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Properties</p>
                <p className="text-2xl font-bold text-gray-900">{properties.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center">
              <AlertCircle className="h-8 w-8 text-amber-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Pending Approvals</p>
                <p className="text-2xl font-bold text-gray-900">{pendingOwners.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center">
              <CheckCircle className="h-8 w-8 text-emerald-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Active Inquiries</p>
                <p className="text-2xl font-bold text-gray-900">{inquiries.length}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Pending Owner Approvals */}
          <div className="bg-white rounded-xl shadow-lg">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900">Pending Owner Approvals</h2>
            </div>

            {pendingOwners.length === 0 ? (
              <div className="p-8 text-center">
                <CheckCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No pending approvals</h3>
                <p className="text-gray-600">All owner applications have been processed.</p>
              </div>
            ) : (
              <div className="divide-y divide-gray-200">
                {pendingOwners.map((owner) => (
                  <div key={owner.id} className="p-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-lg font-medium text-gray-900">{owner.name}</h3>
                        <p className="text-gray-600">{owner.email}</p>
                        <p className="text-gray-600">{owner.phone}</p>
                        <p className="text-xs text-gray-500 mt-2">
                          Applied on {new Date(owner.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleApproveOwner(owner.id)}
                          className="flex items-center space-x-1 bg-green-600 text-white px-3 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm"
                        >
                          <CheckCircle className="h-4 w-4" />
                          <span>Approve</span>
                        </button>
                        <button
                          onClick={() => handleRejectOwner(owner.id)}
                          className="flex items-center space-x-1 bg-red-600 text-white px-3 py-2 rounded-lg hover:bg-red-700 transition-colors text-sm"
                        >
                          <XCircle className="h-4 w-4" />
                          <span>Reject</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Platform Statistics */}
          <div className="bg-white rounded-xl shadow-lg">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900">Platform Statistics</h2>
            </div>

            <div className="p-6 space-y-6">
              {/* User Breakdown */}
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-3">User Distribution</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Renters</span>
                    <span className="text-sm font-medium">{totalRenters}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Approved Owners</span>
                    <span className="text-sm font-medium">{approvedOwners}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Pending Owners</span>
                    <span className="text-sm font-medium">{pendingOwners.length}</span>
                  </div>
                </div>
              </div>

              {/* Property Statistics */}
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-3">Property Statistics</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Available Properties</span>
                    <span className="text-sm font-medium">
                      {properties.filter(p => p.available).length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Rented Properties</span>
                    <span className="text-sm font-medium">
                      {properties.filter(p => !p.available).length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Average Rent</span>
                    <span className="text-sm font-medium">
                      ${Math.round(properties.reduce((sum, p) => sum + p.price, 0) / properties.length).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Recent Activity */}
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-3">Recent Activity</h3>
                <div className="space-y-2">
                  <div className="text-sm text-gray-600">
                    • {inquiries.filter(i => i.status === 'pending').length} new inquiries pending
                  </div>
                  <div className="text-sm text-gray-600">
                    • {pendingOwners.length} owner applications awaiting approval
                  </div>
                  <div className="text-sm text-gray-600">
                    • {properties.filter(p => p.available).length} properties currently available
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
import React, { useState, useEffect } from 'react';
import { Plus, Home, MessageCircle, DollarSign, Edit, Trash2 } from 'lucide-react';
import { Property, Inquiry } from '../../types';
import { mockProperties, mockInquiries } from '../../data/mockData';
import { useAuth } from '../../context/AuthContext';

const OwnerDashboard: React.FC = () => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [showAddProperty, setShowAddProperty] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    // Load owner's properties
    const ownerProperties = mockProperties.filter(p => p.owner.id === user?.id);
    setProperties(ownerProperties);

    // Load inquiries for owner's properties
    const propertyIds = ownerProperties.map(p => p.id);
    const savedInquiries = JSON.parse(localStorage.getItem('inquiries') || '[]');
    const ownerInquiries = [
      ...mockInquiries.filter(i => propertyIds.includes(i.propertyId)),
      ...savedInquiries.filter((i: Inquiry) => propertyIds.includes(i.propertyId))
    ];
    setInquiries(ownerInquiries);
  }, [user]);

  const handleInquiryResponse = (inquiryId: string, status: 'approved' | 'rejected') => {
    setInquiries(prev => prev.map(inquiry => 
      inquiry.id === inquiryId ? { ...inquiry, status } : inquiry
    ));
    
    // Update localStorage
    const savedInquiries = JSON.parse(localStorage.getItem('inquiries') || '[]');
    const updated = savedInquiries.map((inquiry: Inquiry) => 
      inquiry.id === inquiryId ? { ...inquiry, status } : inquiry
    );
    localStorage.setItem('inquiries', JSON.stringify(updated));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  if (!user?.approved) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-xl shadow-lg p-8 text-center">
          <div className="text-amber-600 mb-4">
            <Home className="h-16 w-16 mx-auto" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Account Pending Approval</h2>
          <p className="text-gray-600 mb-6">
            Your owner account is currently under review. You'll be able to add and manage properties once an admin approves your account.
          </p>
          <p className="text-sm text-gray-500">
            This usually takes 24-48 hours. We'll notify you once approved.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Owner Dashboard</h1>
            <p className="text-gray-600 mt-2">Manage your properties and tenant inquiries</p>
          </div>
          <button
            onClick={() => setShowAddProperty(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <Plus className="h-4 w-4" />
            <span>Add Property</span>
          </button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center">
              <Home className="h-8 w-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Properties</p>
                <p className="text-2xl font-bold text-gray-900">{properties.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center">
              <MessageCircle className="h-8 w-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">New Inquiries</p>
                <p className="text-2xl font-bold text-gray-900">
                  {inquiries.filter(i => i.status === 'pending').length}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center">
              <DollarSign className="h-8 w-8 text-amber-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Available Properties</p>
                <p className="text-2xl font-bold text-gray-900">
                  {properties.filter(p => p.available).length}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center">
              <Home className="h-8 w-8 text-red-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Rented Properties</p>
                <p className="text-2xl font-bold text-gray-900">
                  {properties.filter(p => !p.available).length}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Properties List */}
          <div className="bg-white rounded-xl shadow-lg">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900">My Properties</h2>
            </div>

            {properties.length === 0 ? (
              <div className="p-8 text-center">
                <Home className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No properties yet</h3>
                <p className="text-gray-600 mb-4">
                  Start by adding your first property to the platform.
                </p>
                <button
                  onClick={() => setShowAddProperty(true)}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Add Property
                </button>
              </div>
            ) : (
              <div className="divide-y divide-gray-200">
                {properties.map((property) => (
                  <div key={property.id} className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-4">
                        <img
                          src={property.images[0]}
                          alt={property.title}
                          className="w-16 h-16 rounded-lg object-cover"
                        />
                        <div>
                          <h3 className="text-lg font-medium text-gray-900">{property.title}</h3>
                          <p className="text-gray-600">{property.location.city}, {property.location.state}</p>
                          <p className="text-blue-600 font-semibold">${property.price.toLocaleString()}/mo</p>
                          <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full mt-2 ${
                            property.available ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {property.available ? 'Available' : 'Rented'}
                          </span>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <button className="p-2 text-gray-600 hover:text-blue-600 transition-colors">
                          <Edit className="h-4 w-4" />
                        </button>
                        <button className="p-2 text-gray-600 hover:text-red-600 transition-colors">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Inquiries List */}
          <div className="bg-white rounded-xl shadow-lg">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900">Recent Inquiries</h2>
            </div>

            {inquiries.length === 0 ? (
              <div className="p-8 text-center">
                <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No inquiries yet</h3>
                <p className="text-gray-600">
                  Inquiries from potential tenants will appear here.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-gray-200 max-h-96 overflow-y-auto">
                {inquiries.map((inquiry) => {
                  const property = properties.find(p => p.id === inquiry.propertyId);
                  return (
                    <div key={inquiry.id} className="p-6">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h4 className="text-sm font-medium text-gray-900">{inquiry.renterName}</h4>
                          <p className="text-sm text-gray-600">{property?.title}</p>
                        </div>
                        <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(inquiry.status)}`}>
                          {inquiry.status.charAt(0).toUpperCase() + inquiry.status.slice(1)}
                        </span>
                      </div>
                      <p className="text-sm text-gray-700 mb-3">{inquiry.message}</p>
                      <div className="text-xs text-gray-500 mb-3">
                        {inquiry.renterEmail} • {inquiry.renterPhone}
                      </div>
                      {inquiry.status === 'pending' && (
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleInquiryResponse(inquiry.id, 'approved')}
                            className="text-xs bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700 transition-colors"
                          >
                            Approve
                          </button>
                          <button
                            onClick={() => handleInquiryResponse(inquiry.id, 'rejected')}
                            className="text-xs bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700 transition-colors"
                          >
                            Reject
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Add Property Modal would go here */}
        {showAddProperty && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-xl max-w-md w-full p-6">
              <h3 className="text-lg font-semibold mb-4">Add New Property</h3>
              <p className="text-gray-600 mb-4">
                Property addition feature would be implemented here with a comprehensive form.
              </p>
              <button
                onClick={() => setShowAddProperty(false)}
                className="w-full bg-gray-600 text-white py-2 rounded-lg hover:bg-gray-700 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default OwnerDashboard;
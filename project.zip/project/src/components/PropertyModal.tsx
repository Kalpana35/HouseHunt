import React, { useState } from 'react';
import { X, MapPin, Bed, Bath, Square, Calendar, Phone, Mail, Send } from 'lucide-react';
import { Property } from '../types';
import { useAuth } from '../context/AuthContext';

interface PropertyModalProps {
  property: Property | null;
  onClose: () => void;
  onInquiry: (propertyId: string, message: string) => void;
}

const PropertyModal: React.FC<PropertyModalProps> = ({ property, onClose, onInquiry }) => {
  const [message, setMessage] = useState('');
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const { user, isAuthenticated } = useAuth();

  if (!property) return null;

  const handleInquiry = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      onInquiry(property.id, message);
      setMessage('');
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="relative">
          {/* Header */}
          <div className="flex justify-between items-center p-6 border-b">
            <h2 className="text-2xl font-bold text-gray-900">{property.title}</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Image Gallery */}
          <div className="relative">
            <img
              src={property.images[currentImageIndex]}
              alt={property.title}
              className="w-full h-64 sm:h-80 object-cover"
            />
            {property.images.length > 1 && (
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                {property.images.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`w-3 h-3 rounded-full ${
                      index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                    }`}
                  />
                ))}
              </div>
            )}
          </div>

          <div className="p-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Property Details */}
              <div>
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center text-gray-600">
                    <MapPin className="h-5 w-5 mr-2" />
                    <span>{property.location.address}, {property.location.city}, {property.location.state}</span>
                  </div>
                  <span className="text-2xl font-bold text-blue-600">
                    ${property.price.toLocaleString()}/mo
                  </span>
                </div>

                <div className="flex items-center space-x-6 mb-4 text-gray-600">
                  <div className="flex items-center">
                    <Bed className="h-5 w-5 mr-1" />
                    <span>{property.bedrooms || 'Studio'} bed</span>
                  </div>
                  <div className="flex items-center">
                    <Bath className="h-5 w-5 mr-1" />
                    <span>{property.bathrooms} bath</span>
                  </div>
                  <div className="flex items-center">
                    <Square className="h-5 w-5 mr-1" />
                    <span>{property.area} sq ft</span>
                  </div>
                </div>

                <div className="flex items-center mb-4 text-gray-600">
                  <Calendar className="h-5 w-5 mr-2" />
                  <span>Available from {new Date(property.dateAvailable).toLocaleDateString()}</span>
                </div>

                <div className="mb-6">
                  <h3 className="text-lg font-semibold mb-2">Description</h3>
                  <p className="text-gray-600">{property.description}</p>
                </div>

                <div className="mb-6">
                  <h3 className="text-lg font-semibold mb-3">Amenities</h3>
                  <div className="flex flex-wrap gap-2">
                    {property.amenities.map((amenity, index) => (
                      <span
                        key={index}
                        className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm"
                      >
                        {amenity}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Owner Info */}
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="text-lg font-semibold mb-3">Property Owner</h3>
                  <div className="space-y-2">
                    <p className="font-medium">{property.owner.name}</p>
                    <div className="flex items-center text-gray-600">
                      <Phone className="h-4 w-4 mr-2" />
                      <span>{property.owner.phone}</span>
                    </div>
                    <div className="flex items-center text-gray-600">
                      <Mail className="h-4 w-4 mr-2" />
                      <span>{property.owner.email}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Inquiry Form */}
              <div>
                {isAuthenticated && user?.role === 'renter' ? (
                  <div className="bg-blue-50 rounded-lg p-6">
                    <h3 className="text-lg font-semibold mb-4">Send Inquiry</h3>
                    <form onSubmit={handleInquiry}>
                      <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Message to Owner
                        </label>
                        <textarea
                          value={message}
                          onChange={(e) => setMessage(e.target.value)}
                          rows={4}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          placeholder="I'm interested in this property. Can we schedule a viewing?"
                          required
                        />
                      </div>
                      <button
                        type="submit"
                        className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center justify-center"
                      >
                        <Send className="h-4 w-4 mr-2" />
                        Send Inquiry
                      </button>
                    </form>
                  </div>
                ) : (
                  <div className="bg-gray-50 rounded-lg p-6 text-center">
                    <p className="text-gray-600 mb-4">
                      {!isAuthenticated 
                        ? 'Please login as a renter to send inquiries'
                        : 'Only renters can send property inquiries'
                      }
                    </p>
                    {!isAuthenticated && (
                      <button
                        onClick={onClose}
                        className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        Login / Register
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyModal;